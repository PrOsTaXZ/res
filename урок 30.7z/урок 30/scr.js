$(document).ready(function () {
  $.get("https://jsonplaceholder.typicode.com/todos", function (response) {
    console.log(response[1]);
    $("p").html(response[1].title);
  });
});
